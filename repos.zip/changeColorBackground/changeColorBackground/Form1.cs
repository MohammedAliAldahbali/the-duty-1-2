﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace changeColorBackground
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
int i = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            
            timer1.Start();
            
            if(i == 0)
            {
                BackColor = Color.OrangeRed;
            }
            else if (i == 1)
            {
                BackColor = Color.Yellow;
            }
            else if (i == 2)
            {
                BackColor = Color.Magenta;
            }
            else if (i == 3)
            {
                BackColor = Color.Brown;
            }
            else if (i == 4)
            {
                BackColor = Color.Chartreuse;
            }
            else if (i == 5)
            {
                BackColor = Color.Turquoise;
            }
            else if (i == 6)
            {
                BackColor = Color.Salmon;
            }
            i++;
            if (i > 6)
            {
                i=0;
            }
        }
    }
}
