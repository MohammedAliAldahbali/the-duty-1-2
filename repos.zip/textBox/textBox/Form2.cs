﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace textBox
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
            if(radioButton1.Checked == true)
            {
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

                this.BackColor = Color.Red;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            this.BackColor= Color.Black;
            this.ForeColor = Color.White;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            this.BackColor=Color.Green;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            this.BackColor = Color.Yellow;
        }

        private void button1_Click(object sender, EventArgs e)
        {
           int count= this.Controls.Count;
            for(int i=0; i<count; i++)
            {
                listBox1.Items.Add(this.Controls[i].Name);
            }
        }
    }
}
